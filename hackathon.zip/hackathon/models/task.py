import datetime
from odoo import fields,api,models,_
class Task(models.Model):
    
    _name='task'
    _rec_name = 'name'
    
    image = fields.Binary()
    name = fields.Char(string='name', required=True)
    partner_ids = fields.Many2many('res.partner', string ='Partners')
    archives = fields.Char(string='Not Archived')
    leaves_left = fields.Integer(string='Leaves Left')
    contacts = fields.Integer(string='Contacts')
    timesheet = fields.Integer(string='Timesheets')
    pay_slip = fields.Integer(string='Payslips')
    apperaisals = fields.Integer(string='Appraisals')
    it_declr_ids = fields.One2many('it.decl', 'task_id',string='Declaration')
    
    def archives_(self):
        pass

    def leaves_left_(self):
        pass

    def contacts_(self):
        pass

    def timesheet_(self):
        pass

    def pay_slip_(self):
        pass

    def apperaisals_(self):
        pass


class IT_Declaration(models.Model):
    
    _name='it.decl'
    _rec_name = 'year_date'
    @api.depends('year_date')
    def _get_year(self):
        year_list = []
#         print "uyyyyyyyyyyyyyyyyyyyyyy"
        for i in range(2000,3000):
            d = str(i)+"-"+str(i+1)
#             print '%%%%%%%%%%%%%%% ooooooooooooooooooooo',d
            year_list.append((i,d))
        return year_list
    
    year_date = fields.Selection(_get_year,string='Financial Year')
    financial_year = fields.Many2one('finance.year',string='Financial Year')
    lock_date = fields.Date(string='Locking Date')
    task_id = fields.Many2one('task', string='Task')
    it_lines_ids = fields.One2many('it.decl.line', 'it_declr_id', string='IT Declaration Lines')

class Financie_Year(models.Model):
    
    _name='finance.year'
    _rec_name = 'name'
    name = fields.Char('Name')
    code = fields.Char('Income Tax Section Codes') 
    
    
class IT_Declaration_Line(models.Model):
    
    _name='it.decl.line'
    
    
    it_section = fields.Selection([('boc','BOC'),('euc_via','Exemtion under chapter VIA')],
                                  string='IT Section')
    max_limit = fields.Float(string='Maximum Limit')
    tot_decl = fields.Float(string='Total Declaration')
    it_declr_id = fields.Many2one('it.decl', string='IT Declaration')
    it_sec_ids = fields.One2many('it.sec.decl', 'it_decl_line_id', string='IT Section Lines')
    
class IT_Section_Declaration_Line(models.Model):
    
    _name='it.sec.decl'
    _rec_name = 'it_declaration'

    it_declaration = fields.Char('IT Declaration')
    amount = fields.Float('Amount')
    verified = fields.Boolean('Verified')
    it_decl_line_id = fields.Many2one('it.decl.line',)
    sec_attach_ids = fields.One2many('it.attach.line', 'sec_id', string='Attachments')
    
class IT_Attach_Line(models.Model):
    
    _name='it.attach.line'
    _rec_name = 'name'
    
    sec_id =fields.Many2one('it.sec.decl')
    name = fields.Char('Attachment Name')
    attechment = fields.Binary(string="Attachment name", track_visibility='onchange')
    resource_mo = fields.Char('Resource Model')
    resource_field = fields.Char('Resource Field')
    resource_id = fields.Integer('Resource ID')
#     type = fields.Many2one('attch.type', string='Type')
    owner = fields.Char('Owner')
    
class Attach_Type(models.Model):
    
    _name='attach.type'
    _rec_name = 'name'
    
    name = fields.Char('Type')
    

    
    
    

