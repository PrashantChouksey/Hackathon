{
    'name': 'Pragmatic Hackathon',
    'version': '10.0.0.1.0',
    'category': '',
    'sequence': 90,
    'summary': 'This is for Pragmatic Hackathon Task',
    'description': """
""",
    "author" : "Prashant Chouksey",
    'depends': [],
    'data': [
             'view/task_view.xml',
             ],
    'demo': [],
    'test': [],
    'installable': True,
    'auto_install': False,
    'application': True,
}
